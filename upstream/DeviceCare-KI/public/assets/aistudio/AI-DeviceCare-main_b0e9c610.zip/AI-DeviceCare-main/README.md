# AI-DeviceCare

**Status:** P0 Android foundation was merged; M1 consumer **local collector preview** is under development and not publicly released.

A privacy-first Android security and device-health platform, designed as two differentiated applications supported by one modular Kotlin/Jetpack Compose codebase.

- **AI-DeviceCare** (consumer): safer permission analysis, battery insights, device diagnostics, storage review, guided remediation, and progressively validated malware/network safety features.
- **AI-DeviceCare+** (business): planned organizational device posture, role-based management, consented device enrollment and multi-device reporting. A separate app is only released when it delivers demonstrably distinct business value.

## Planned release sequence

| Stage | Scope | Store readiness |
| --- | --- | --- |
| P0 / M0 | Governance, capability matrix, native Android skeleton, CI | Internal only |
| M1 | Free + Starter: app/permission posture, battery, diagnostics, safe cleaner, logging | First candidate public app |
| M2 | Pro: validated malware inspection, signatures and reports | Feature release |
| M3 | Elite: DNS/ad/tracker filtering, optional licensed VPN | Feature release |
| M4 | AI-DeviceCare+: true business fleet management and organizational dashboard | Separate business launch |
| M5 | Business enhancements: enterprise controls, reporting, SSO | Incremental release |

## Product principles

- **No root and no ADB.** Public Android APIs only; supported manual settings flows for OS-controlled actions.
- **No false guarantees.** Android cannot universally clear all internal caches of all apps or reveal all other applications' hidden system activity.
- **Permission, data and user-consent minimization.** Sensitive permissions gated by policy and separate user consent.
- **Explainable evidence, not fear-based detections.** No malware verdict without testable evidence, risk confidence and false-positive handling.
- **Battery-aware by design.** Diagnostics must not become the cause of device drain.
- **Safe fixes.** Preview changes, require permission, log and verify after action.

## Documentation

- [Repository & agent rules](AGENTS.md)
- [Capital-AI adapted skills](.agents/skills/README.md) and [Governance-as-Code](docs/GOVERNANCE-AS-CODE.md)
- [Planned modular architecture and milestones](docs/ARCHITECTURE.md)
- [Android capability and Play permission matrix](docs/ANDROID_CAPABILITY_MATRIX.md)
- [Product master roadmap — GitHub Issue #1](https://github.com/SvenKulessa/AI-DeviceCare/issues/1)

- [M1 BatteryManager + scoped permissions collectors and privacy rules](docs/M1-COLLECTORS.md)

## One project folder

This repository root is the only Gradle project root. Both future apps are Android modules under `apps/`, supported by reusable `core/` and `features/` modules. The P0 policy validator guards against nested project settings and unreviewed high-risk manifest permissions. Run `node --test scripts/validate-governance.test.mjs` and `node scripts/validate-governance.mjs` (Node.js 20+).

## Contributing / development state

The P0 Gradle project, both internal Android apps and independent Core QA and scoring pipelines exist. Consumer M1 adds **on-demand** battery/visible-permission aggregate readings without sensitive manifest permissions. CI covers pure Kotlin negative fixtures, both app builds and Android lint. Physical Android QA, release signing, Play review, production scoring, VPN and billing are **not proven**.

Only internal debug APKs are built; no signed production APK/AAB or accepted Play Store listing is claimed.
